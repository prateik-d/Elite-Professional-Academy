import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { HeaderComponent } from './user/header/header.component';
import { BannerComponent } from './user/banner/banner.component';
import { FeatureComponent } from './user/feature/feature.component';
import { AbilityComponent } from './user/ability/ability.component';
import { TopServicesComponent } from './user/top-services/top-services.component';
import { RegervationComponent } from './user/regervation/regervation.component';
import { TeamComponent } from './user/team/team.component';
import { VideoComponent } from './user/video/video.component';
import { BlogComponent } from './user/blog/blog.component';
import { FooterComponent } from './user/footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    HeaderComponent,
    BannerComponent,
    FeatureComponent,
    AbilityComponent,
    TopServicesComponent,
    RegervationComponent,
    TeamComponent,
    VideoComponent,
    BlogComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
