import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegervationComponent } from './regervation.component';

describe('RegervationComponent', () => {
  let component: RegervationComponent;
  let fixture: ComponentFixture<RegervationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegervationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegervationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
