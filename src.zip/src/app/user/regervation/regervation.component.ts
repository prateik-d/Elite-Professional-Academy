import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regervation',
  templateUrl: './regervation.component.html',
  styleUrls: ['./regervation.component.css']
})
export class RegervationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
